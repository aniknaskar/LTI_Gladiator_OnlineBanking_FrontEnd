export class ChangeTransactionPassword
{
    accountNumber:string;
    transactionPassword:string;
}