export class Otp {
    public internetBankingId : string;
    public otp : Number;

    constructor(internetBankingId : string,otp: Number)
    {
        this.internetBankingId=internetBankingId;
        this.otp=otp;
    }

   
    

}