export class GetTransaction
{
    accountNumber:string;
    fromDate:any;
    toDate:any;
}