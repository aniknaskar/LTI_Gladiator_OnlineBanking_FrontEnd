export class Login {
    public internetBankingId : string;
    public loginPassword : string;
    public accountNumber:string;
    public customerName:string;
    public accountBalance:string
    public transactionPassword:string;
    public numberOfAttemptedLogin:number;
    public isLocked:number;

    
    

   
    

}