export class Transaction
{
    modeOfTransaction:string;
    amount:string;
    customerAccountNumber:string;
    beneficiaryAccountNumber:string;
    dateOfPayment:any;
    serialNumber:number;
}

export class Dates
{

  startDate : any;
  endDate : any;

}