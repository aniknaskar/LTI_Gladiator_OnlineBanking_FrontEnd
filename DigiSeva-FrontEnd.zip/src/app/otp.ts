export class OTP
{
    otp:string;
    internetBankingId:string;
}