export class TransactionResponse
{
    response:string;
}