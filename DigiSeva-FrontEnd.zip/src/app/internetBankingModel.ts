export class internetBanking{

    accountNumber : number;
    loginPassword : string;
    confirmLoginPassword : string;
    transactionPassword : string;
    confirmTransactionPassword : string;
    
   
}