export class ChangeLoginPassword
{
    internetBankingId:string;
    loginPassword:string;
}