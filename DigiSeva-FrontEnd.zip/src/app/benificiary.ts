export class Beneficiary {
    customerAccountNumber:string;
    beneficiaryName: string;
    beneficiaryAccountNumber: string;
    beneficiaryConfirmAccountNumber: string;
    beneficiaryNickName: string;
}